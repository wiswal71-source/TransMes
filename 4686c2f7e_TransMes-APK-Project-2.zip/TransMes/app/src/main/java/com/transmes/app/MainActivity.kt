package com.transmes.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.mlkit.nl.translate.TranslateLanguage
import com.transmes.app.databinding.ActivityMainBinding
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: MessageAdapter

    private val requestPermission = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val granted = permissions[Manifest.permission.RECEIVE_SMS] == true &&
                permissions[Manifest.permission.READ_SMS] == true
        if (granted) {
            Toast.makeText(this, "تم منح صلاحيات الرسائل", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "يجب منح صلاحيات قراءة واستقبال الرسائل", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // تهيئة محرك الصوت مبكراً
        TtsHelper.init(this)

        checkPermissions()
        setupLanguageSpinner()
        setupSpeakSwitch()
        setupRecyclerView()
        observeMessages()

        binding.btnClear.setOnClickListener {
            lifecycleScope.launch {
                AppDatabase.getInstance(this@MainActivity).messageDao().clearAll()
                Toast.makeText(this@MainActivity, "تم مسح الرسائل", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun checkPermissions() {
        val permissions = mutableListOf(
            Manifest.permission.RECEIVE_SMS,
            Manifest.permission.READ_SMS
        )
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        val needRequest = permissions.any {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (needRequest) {
            requestPermission.launch(permissions.toTypedArray())
        }
    }

    private fun setupLanguageSpinner() {
        val languages = linkedMapOf(
            "العربية" to TranslateLanguage.ARABIC,
            "English" to TranslateLanguage.ENGLISH,
            "Français" to TranslateLanguage.FRENCH,
            "Deutsch" to TranslateLanguage.GERMAN,
            "Español" to TranslateLanguage.SPANISH,
            "Türkçe" to TranslateLanguage.TURKISH,
            "Русский" to TranslateLanguage.RUSSIAN,
            "Italiano" to TranslateLanguage.ITALIAN,
            "Português" to TranslateLanguage.PORTUGUESE
        )

        val spinnerAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            languages.keys.toList()
        )
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerLang.adapter = spinnerAdapter

        val prefs = getSharedPreferences("transmes_prefs", MODE_PRIVATE)
        val savedLang = prefs.getString("target_lang", TranslateLanguage.ARABIC)
        val index = languages.values.indexOf(savedLang).coerceAtLeast(0)
        binding.spinnerLang.setSelection(index)

        binding.spinnerLang.onItemSelectedListener =
            object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: android.widget.AdapterView<*>?,
                    view: android.view.View?,
                    position: Int,
                    id: Long
                ) {
                    val selected = languages.values.elementAt(position)
                    prefs.edit().putString("target_lang", selected).apply()
                }

                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            }
    }

    private fun setupSpeakSwitch() {
        val prefs = getSharedPreferences("transmes_prefs", MODE_PRIVATE)
        val speakEnabled = prefs.getBoolean("speak_enabled", true)
        binding.switchSpeak.isChecked = speakEnabled

        binding.switchSpeak.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("speak_enabled", isChecked).apply()
            val msg = if (isChecked) "تم تفعيل القراءة الصوتية" else "تم إيقاف القراءة الصوتية"
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupRecyclerView() {
        adapter = MessageAdapter()
        binding.recyclerMessages.layoutManager = LinearLayoutManager(this)
        binding.recyclerMessages.adapter = adapter
    }

    private fun observeMessages() {
        lifecycleScope.launch {
            AppDatabase.getInstance(this@MainActivity)
                .messageDao()
                .getAllMessages()
                .collectLatest { list ->
                    adapter.submitList(list)
                }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        // لا نغلق الـ TTS هنا لأن الـ Receiver قد يحتاجه
    }
}
