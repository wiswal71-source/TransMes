package com.transmes.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.util.Log
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SmsReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        // تهيئة محرك الصوت
        TtsHelper.init(context)

        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        val fullMessage = StringBuilder()
        var sender = "Unknown"

        for (sms in messages) {
            sender = sms.originatingAddress ?: "Unknown"
            fullMessage.append(sms.messageBody)
        }

        val originalText = fullMessage.toString().trim()
        if (originalText.isEmpty()) return

        Log.d("TransMes", "New SMS from $sender: $originalText")

        val prefs = context.getSharedPreferences("transmes_prefs", Context.MODE_PRIVATE)
        val targetLang = prefs.getString("target_lang", TranslateLanguage.ARABIC)
            ?: TranslateLanguage.ARABIC

        // هل القراءة الصوتية مفعلة؟ (افتراضي: نعم)
        val speakEnabled = prefs.getBoolean("speak_enabled", true)

        translateAndSave(context, sender, originalText, targetLang, speakEnabled)
    }

    private fun translateAndSave(
        context: Context,
        sender: String,
        original: String,
        targetLang: String,
        speakEnabled: Boolean
    ) {
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(targetLang)
            .build()

        val translator = Translation.getClient(options)

        translator.downloadModelIfNeeded()
            .addOnSuccessListener {
                translator.translate(original)
                    .addOnSuccessListener { translated ->
                        // حفظ الرسالة
                        CoroutineScope(Dispatchers.IO).launch {
                            val db = AppDatabase.getInstance(context)
                            db.messageDao().insert(
                                MessageEntity(
                                    sender = sender,
                                    original = original,
                                    translated = translated,
                                    timestamp = System.currentTimeMillis()
                                )
                            )
                        }

                        // إشعار
                        NotificationHelper.showNotification(context, sender, translated)

                        // قراءة صوتية
                        if (speakEnabled) {
                            TtsHelper.speak(translated, targetLang)
                        }
                    }
                    .addOnFailureListener { e ->
                        Log.e("TransMes", "Translation failed", e)
                    }
            }
            .addOnFailureListener { e ->
                Log.e("TransMes", "Model download failed", e)
            }
    }
}
