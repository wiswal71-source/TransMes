package com.transmes.app

import android.content.Context
import android.speech.tts.TextToSpeech
import android.util.Log
import java.util.Locale

object TtsHelper {

    private var tts: TextToSpeech? = null
    private var isReady = false

    fun init(context: Context) {
        if (tts != null) return

        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                isReady = true
                Log.d("TransMes", "TTS initialized successfully")
            } else {
                Log.e("TransMes", "TTS initialization failed")
            }
        }
    }

    fun speak(text: String, languageCode: String) {
        if (tts == null || !isReady) {
            Log.w("TransMes", "TTS not ready yet")
            return
        }

        val locale = when (languageCode) {
            "ar" -> Locale("ar")
            "en" -> Locale.ENGLISH
            "fr" -> Locale.FRENCH
            "de" -> Locale.GERMAN
            "es" -> Locale("es")
            "tr" -> Locale("tr")
            "ru" -> Locale("ru")
            "it" -> Locale.ITALIAN
            "pt" -> Locale("pt")
            else -> Locale.ENGLISH
        }

        tts?.language = locale
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "transmes_utterance")
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        isReady = false
    }
}
